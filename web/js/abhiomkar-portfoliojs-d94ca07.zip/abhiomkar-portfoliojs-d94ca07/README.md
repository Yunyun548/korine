Portfoliojs
==========
jQuery plugin for your beautiful portfolio images with horizontal scrolling

* Demo / Usage: http://portfoliojs.com
* Author: Abhinay Omkar
